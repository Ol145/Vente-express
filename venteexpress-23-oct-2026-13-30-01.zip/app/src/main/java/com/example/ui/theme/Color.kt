package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Brand
val EmeraldDark = Color(0xFF0F5132)
val EmeraldPrimary = Color(0xFF137547)
val EmeraldLight = Color(0xFF2E935E)
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppDark = Color(0xFF075E54)

// Warm Accents
val AmberGold = Color(0xFFD97706)
val AmberLight = Color(0xFFFDE68A)

// Surfaces & Neutrals
val SurfaceLight = Color(0xFFF8F9FA)
val SurfaceCard = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1F2937)
val TextMuted = Color(0xFF6B7280)
val BorderLight = Color(0xFFE5E7EB)

// Dark Theme Variants
val DarkBackground = Color(0xFF111827)
val DarkSurface = Color(0xFF1F2937)
val DarkSurfaceElevated = Color(0xFF374151)
val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF9CA3AF)

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ProductIcon(
    iconName: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    iconSize: Dp = 24.dp
) {
    val (icon, gradient) = getIconAndGradient(iconName)

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(brush = gradient),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(iconSize)
        )
    }
}

fun getIconAndGradient(iconName: String): Pair<ImageVector, Brush> {
    return when (iconName.lowercase()) {
        "phone", "smartphone" -> Icons.Default.Smartphone to Brush.linearGradient(
            listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
        )
        "watch" -> Icons.Default.Watch to Brush.linearGradient(
            listOf(Color(0xFF7C3AED), Color(0xFF6D28D9))
        )
        "headset", "headphones" -> Icons.Default.Headphones to Brush.linearGradient(
            listOf(Color(0xFFEC4899), Color(0xFFDB2777))
        )
        "shoe" -> Icons.Default.LocalMall to Brush.linearGradient(
            listOf(Color(0xFFF97316), Color(0xFFEA580C))
        )
        "shirt" -> Icons.Default.Checkroom to Brush.linearGradient(
            listOf(Color(0xFF10B981), Color(0xFF059669))
        )
        "bag" -> Icons.Default.ShoppingBag to Brush.linearGradient(
            listOf(Color(0xFFD97706), Color(0xFFB45309))
        )
        "laptop" -> Icons.Default.Laptop to Brush.linearGradient(
            listOf(Color(0xFF0284C7), Color(0xFF0369A1))
        )
        "gem" -> Icons.Default.Diamond to Brush.linearGradient(
            listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9))
        )
        "camera" -> Icons.Default.PhotoCamera to Brush.linearGradient(
            listOf(Color(0xFFE11D48), Color(0xFFBE123C))
        )
        else -> Icons.Default.CardGiftcard to Brush.linearGradient(
            listOf(Color(0xFF137547), Color(0xFF0F5132))
        )
    }
}

val AvailableIconNames = listOf(
    "phone" to "Téléphone",
    "watch" to "Montre",
    "shoe" to "Chaussures",
    "headset" to "Casque audio",
    "shirt" to "Vêtement",
    "bag" to "Sac / Bagagerie",
    "laptop" to "Ordinateur",
    "gem" to "Bijou / Luxe",
    "camera" to "Appareil photo"
)

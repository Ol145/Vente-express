package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.OrderLog
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.example.data.repository.ShopRepository
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    CATALOG,
    ADMIN
}

data class OrderSheetState(
    val isOpen: Boolean = false,
    val product: Product? = null,
    val quantity: Int = 1,
    val buyerName: String = "",
    val buyerCity: String = ""
)

class ShopViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ShopRepository

    private val _currentScreen = MutableStateFlow(AppScreen.CATALOG)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Tous")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _orderSheetState = MutableStateFlow(OrderSheetState())
    val orderSheetState: StateFlow<OrderSheetState> = _orderSheetState.asStateFlow()

    private val _adminPinDialogVisible = MutableStateFlow(false)
    val adminPinDialogVisible: StateFlow<Boolean> = _adminPinDialogVisible.asStateFlow()

    private val _productEditorDialogVisible = MutableStateFlow(false)
    val productEditorDialogVisible: StateFlow<Boolean> = _productEditorDialogVisible.asStateFlow()

    private val _productToEdit = MutableStateFlow<Product?>(null)
    val productToEdit: StateFlow<Product?> = _productToEdit.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        val database = AppDatabase.getInstance(application)
        repository = ShopRepository(
            database.productDao(),
            database.storeSettingsDao(),
            database.orderLogDao()
        )
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    val storeSettings: StateFlow<StoreSettings> = repository.settingsFlow
        .map { it ?: StoreSettings() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StoreSettings()
        )

    val allOrders: StateFlow<List<OrderLog>> = repository.ordersFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val products: StateFlow<List<Product>> = combine(
        repository.productsFlow,
        _searchQuery,
        _selectedCategory
    ) { allProducts, query, category ->
        allProducts.filter { product ->
            val matchesQuery = query.isBlank() ||
                    product.title.contains(query, ignoreCase = true) ||
                    product.description.contains(query, ignoreCase = true)
            val matchesCategory = category == "Tous" || product.category.equals(category, ignoreCase = true)
            matchesQuery && matchesCategory
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.ADMIN && !_isAdminLoggedIn.value) {
            _adminPinDialogVisible.value = true
        } else {
            _currentScreen.value = screen
        }
    }

    fun showPinDialog() {
        _adminPinDialogVisible.value = true
    }

    fun dismissPinDialog() {
        _adminPinDialogVisible.value = false
    }

    fun verifyAdminPin(enteredPin: String): Boolean {
        val currentPin = storeSettings.value.adminPin
        return if (enteredPin.trim() == currentPin.trim()) {
            _isAdminLoggedIn.value = true
            _adminPinDialogVisible.value = false
            _currentScreen.value = AppScreen.ADMIN
            true
        } else {
            false
        }
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        _currentScreen.value = AppScreen.CATALOG
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun openOrderSheet(product: Product) {
        _orderSheetState.value = OrderSheetState(
            isOpen = true,
            product = product,
            quantity = 1,
            buyerName = _orderSheetState.value.buyerName,
            buyerCity = _orderSheetState.value.buyerCity
        )
    }

    fun updateOrderBuyerName(name: String) {
        _orderSheetState.value = _orderSheetState.value.copy(buyerName = name)
    }

    fun updateOrderBuyerCity(city: String) {
        _orderSheetState.value = _orderSheetState.value.copy(buyerCity = city)
    }

    fun updateOrderQuantity(qty: Int) {
        if (qty in 1..99) {
            _orderSheetState.value = _orderSheetState.value.copy(quantity = qty)
        }
    }

    fun closeOrderSheet() {
        _orderSheetState.value = _orderSheetState.value.copy(isOpen = false, product = null)
    }

    fun confirmOrderAndSendWhatsApp(context: Context) {
        val state = _orderSheetState.value
        val product = state.product ?: return
        val settings = storeSettings.value
        val total = product.priceFcfa * state.quantity

        val message = WhatsAppHelper.buildOrderMessage(
            greeting = settings.sellerGreeting,
            productTitle = product.title,
            productId = product.id,
            quantity = state.quantity,
            unitPrice = product.priceFcfa,
            totalPrice = total,
            buyerName = state.buyerName,
            buyerCity = state.buyerCity
        )

        // Save order log
        viewModelScope.launch {
            repository.logOrder(
                OrderLog(
                    productId = product.id,
                    productTitle = product.title,
                    quantity = state.quantity,
                    unitPrice = product.priceFcfa,
                    totalPrice = total,
                    buyerName = state.buyerName.ifBlank { "Client Anonyme" },
                    buyerCity = state.buyerCity.ifBlank { "Non renseigné" }
                )
            )
        }

        // Send to WhatsApp
        val success = WhatsAppHelper.sendWhatsAppOrder(
            context = context,
            phoneNumber = settings.whatsappNumber,
            message = message
        )

        if (success) {
            closeOrderSheet()
            _statusMessage.value = "Redirection vers WhatsApp du vendeur..."
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // Admin product actions
    fun openProductEditor(product: Product? = null) {
        _productToEdit.value = product
        _productEditorDialogVisible.value = true
    }

    fun closeProductEditor() {
        _productToEdit.value = null
        _productEditorDialogVisible.value = false
    }

    fun saveProduct(
        id: Int,
        title: String,
        description: String,
        priceFcfa: Int,
        category: String,
        stock: Int,
        iconName: String
    ) {
        if (!_isAdminLoggedIn.value) return

        viewModelScope.launch {
            val product = Product(
                id = if (id > 0) id else 0,
                title = title.trim(),
                description = description.trim(),
                priceFcfa = priceFcfa,
                category = category.trim().ifBlank { "Général" },
                stock = stock,
                iconName = iconName
            )

            if (id > 0) {
                repository.updateProduct(product)
                _statusMessage.value = "Article modifié avec succès"
            } else {
                repository.insertProduct(product)
                _statusMessage.value = "Nouvel article ajouté au catalogue"
            }
            closeProductEditor()
        }
    }

    fun deleteProduct(product: Product) {
        if (!_isAdminLoggedIn.value) return
        viewModelScope.launch {
            repository.deleteProduct(product)
            _statusMessage.value = "Article « ${product.title} » supprimé"
        }
    }

    // Admin settings actions
    fun updateStoreSettings(
        storeName: String,
        whatsappNumber: String,
        greeting: String
    ) {
        if (!_isAdminLoggedIn.value) return
        viewModelScope.launch {
            val current = storeSettings.value
            val updated = current.copy(
                storeName = storeName.trim(),
                whatsappNumber = whatsappNumber.trim(),
                sellerGreeting = greeting.trim()
            )
            repository.updateSettings(updated)
            _statusMessage.value = "Paramètres de la boutique mis à jour"
        }
    }

    fun updateAdminPin(oldPin: String, newPin: String): Boolean {
        if (!_isAdminLoggedIn.value) return false
        val current = storeSettings.value
        if (oldPin.trim() != current.adminPin.trim()) {
            return false
        }
        viewModelScope.launch {
            val updated = current.copy(adminPin = newPin.trim())
            repository.updateSettings(updated)
            _statusMessage.value = "Code PIN administrateur modifié avec succès"
        }
        return true
    }
}

package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductEditorDialog(
    product: Product?,
    onDismiss: () -> Unit,
    onSave: (id: Int, title: String, description: String, priceFcfa: Int, category: String, stock: Int, iconName: String) -> Unit
) {
    var title by remember { mutableStateOf(product?.title ?: "") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var priceStr by remember { mutableStateOf(product?.priceFcfa?.toString() ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "High-Tech") }
    var stockStr by remember { mutableStateOf(product?.stock?.toString() ?: "10") }
    var selectedIcon by remember { mutableStateOf(product?.iconName ?: "bag") }

    var titleError by remember { mutableStateOf(false) }
    var priceError by remember { mutableStateOf(false) }

    val isEditing = product != null
    val scrollState = rememberScrollState()

    val suggestedCategories = listOf("High-Tech", "Mode", "Accessoires", "Maison", "Beauté")

    fun submit() {
        var hasError = false
        if (title.isBlank()) {
            titleError = true
            hasError = true
        }
        val price = priceStr.toIntOrNull()
        if (price == null || price <= 0) {
            priceError = true
            hasError = true
        }

        if (!hasError) {
            val stock = stockStr.toIntOrNull() ?: 1
            onSave(
                product?.id ?: 0,
                title.trim(),
                description.trim(),
                price!!,
                category.trim(),
                stock,
                selectedIcon
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Modifier l'article" else "Ajouter un article",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        titleError = false
                    },
                    label = { Text("Nom du produit *") },
                    placeholder = { Text("Ex: iPhone 15 Pro") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, tint = EmeraldPrimary)
                    },
                    singleLine = true,
                    isError = titleError,
                    supportingText = if (titleError) {
                        { Text("Le nom du produit est requis") }
                    } else null,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Price FCFA
                OutlinedTextField(
                    value = priceStr,
                    onValueChange = {
                        priceStr = it.filter { char -> char.isDigit() }
                        priceError = false
                    },
                    label = { Text("Prix en FCFA *") },
                    placeholder = { Text("Ex: 50000") },
                    trailingIcon = { Text("FCFA", fontWeight = FontWeight.Bold, color = EmeraldPrimary, modifier = Modifier.padding(end = 12.dp)) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = EmeraldPrimary)
                    },
                    singleLine = true,
                    isError = priceError,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    supportingText = if (priceError) {
                        { Text("Entrez un prix numérique valide en FCFA") }
                    } else null,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_price_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Selection & Custom Category
                Text("Catégorie", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestedCategories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Autre catégorie") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Category, contentDescription = null, tint = EmeraldPrimary)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_category_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Stock
                OutlinedTextField(
                    value = stockStr,
                    onValueChange = { stockStr = it.filter { char -> char.isDigit() } },
                    label = { Text("Stock disponible") },
                    placeholder = { Text("Ex: 10") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Inventory, contentDescription = null, tint = EmeraldPrimary)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_stock_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Icon / Type de produit
                Text("Icône visuelle de l'article", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AvailableIconNames.forEach { (iconKey, label) ->
                        val isSelected = selectedIcon == iconKey
                        Surface(
                            onClick = { selectedIcon = iconKey },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, EmeraldPrimary) else null,
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProductIcon(iconName = iconKey, size = 28.dp, iconSize = 16.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description de l'article") },
                    placeholder = { Text("Caractéristiques, état, garantie, etc.") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = EmeraldPrimary)
                    },
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_description_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { submit() },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_product_button")
            ) {
                Text(if (isEditing) "Enregistrer" else "Ajouter")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("cancel_product_button")
            ) {
                Text("Annuler")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}

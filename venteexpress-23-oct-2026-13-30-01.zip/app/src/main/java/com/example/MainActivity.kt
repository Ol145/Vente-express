package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AdminPinDialog
import com.example.ui.components.OrderBottomSheet
import com.example.ui.components.ProductEditorDialog
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ShopViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ShopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: ShopViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val storeSettings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    val orderSheetState by viewModel.orderSheetState.collectAsStateWithLifecycle()
    val adminPinDialogVisible by viewModel.adminPinDialogVisible.collectAsStateWithLifecycle()
    val productEditorDialogVisible by viewModel.productEditorDialogVisible.collectAsStateWithLifecycle()
    val productToEdit by viewModel.productToEdit.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Handle back button on secondary screens
    if (currentScreen == AppScreen.ADMIN) {
        BackHandler {
            viewModel.navigateTo(AppScreen.CATALOG)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        when (currentScreen) {
            AppScreen.CATALOG -> {
                CatalogScreen(
                    storeSettings = storeSettings,
                    products = products,
                    searchQuery = searchQuery,
                    selectedCategory = selectedCategory,
                    isAdminLoggedIn = isAdminLoggedIn,
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onCategorySelect = { viewModel.setCategory(it) },
                    onProductClick = { viewModel.openOrderSheet(it) },
                    onAdminClick = {
                        if (isAdminLoggedIn) {
                            viewModel.navigateTo(AppScreen.ADMIN)
                        } else {
                            viewModel.showPinDialog()
                        }
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }

            AppScreen.ADMIN -> {
                AdminScreen(
                    storeSettings = storeSettings,
                    products = products,
                    orders = orders,
                    onBackToCatalog = { viewModel.navigateTo(AppScreen.CATALOG) },
                    onLogout = { viewModel.logoutAdmin() },
                    onOpenAddProduct = { viewModel.openProductEditor(null) },
                    onOpenEditProduct = { viewModel.openProductEditor(it) },
                    onDeleteProduct = { viewModel.deleteProduct(it) },
                    onUpdateStoreSettings = { storeName, whatsappNumber, greeting ->
                        viewModel.updateStoreSettings(storeName, whatsappNumber, greeting)
                    },
                    onUpdateAdminPin = { oldPin, newPin ->
                        viewModel.updateAdminPin(oldPin, newPin)
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }

        // Admin PIN Unlock Dialog
        if (adminPinDialogVisible) {
            AdminPinDialog(
                onDismiss = { viewModel.dismissPinDialog() },
                onConfirm = { enteredPin ->
                    viewModel.verifyAdminPin(enteredPin)
                }
            )
        }

        // Customer Order Bottom Sheet
        if (orderSheetState.isOpen && orderSheetState.product != null) {
            OrderBottomSheet(
                product = orderSheetState.product!!,
                quantity = orderSheetState.quantity,
                buyerName = orderSheetState.buyerName,
                buyerCity = orderSheetState.buyerCity,
                sellerPhone = storeSettings.whatsappNumber,
                onQuantityChange = { viewModel.updateOrderQuantity(it) },
                onBuyerNameChange = { viewModel.updateOrderBuyerName(it) },
                onBuyerCityChange = { viewModel.updateOrderBuyerCity(it) },
                onConfirmOrder = { viewModel.confirmOrderAndSendWhatsApp(context) },
                onDismiss = { viewModel.closeOrderSheet() }
            )
        }

        // Admin Product Editor Dialog
        if (productEditorDialogVisible) {
            ProductEditorDialog(
                product = productToEdit,
                onDismiss = { viewModel.closeProductEditor() },
                onSave = { id, title, description, priceFcfa, category, stock, iconName ->
                    viewModel.saveProduct(id, title, description, priceFcfa, category, stock, iconName)
                }
            )
        }
    }
}

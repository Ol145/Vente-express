package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.OrderLog
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Product::class, StoreSettings::class, OrderLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun storeSettingsDao(): StoreSettingsDao
    abstract fun orderLogDao(): OrderLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vente_express.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate with default store settings and sample products
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getInstance(context)
                            database.storeSettingsDao().insertOrUpdate(
                                StoreSettings(
                                    id = 1,
                                    storeName = "VenteExpress Boutique",
                                    whatsappNumber = "+221770000000",
                                    adminPin = "1234",
                                    currency = "FCFA",
                                    sellerGreeting = "Bonjour VenteExpress, je souhaite commander :"
                                )
                            )
                            database.productDao().insertProducts(getDefaultProducts())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        fun getDefaultProducts(): List<Product> = listOf(
            Product(
                id = 1,
                title = "Samsung Galaxy S24 Ultra",
                description = "Smartphone 256Go, écran Dynamic AMOLED 2X 120Hz, caméra 200MP avec S-Pen inclus. Garantie 1 an.",
                priceFcfa = 650000,
                category = "High-Tech",
                stock = 5,
                iconName = "phone"
            ),
            Product(
                id = 2,
                title = "Montre Connectée Pro Titanium",
                description = "Montre intelligente avec écran AMOLED, cardiofréquencemètre, autonomie 7 jours et notifications WhatsApp.",
                priceFcfa = 45000,
                category = "Accessoires",
                stock = 12,
                iconName = "watch"
            ),
            Product(
                id = 3,
                title = "Sneakers Air Street Style",
                description = "Baskets tendance ultra confort avec semelle amortissante. Tailles disponibles du 40 au 45.",
                priceFcfa = 28000,
                category = "Mode",
                stock = 8,
                iconName = "shoe"
            ),
            Product(
                id = 4,
                title = "Casque Bluetooth Bass+ ANC",
                description = "Casque audio avec réduction active de bruit, autonomie record de 40 heures et basses profondes.",
                priceFcfa = 35000,
                category = "High-Tech",
                stock = 15,
                iconName = "headset"
            ),
            Product(
                id = 5,
                title = "Chemise Wax Prestige",
                description = "Chemise confectionnée en véritable tissu Wax 100% coton, coupe moderne pour toutes occasions.",
                priceFcfa = 18500,
                category = "Mode",
                stock = 10,
                iconName = "shirt"
            ),
            Product(
                id = 6,
                title = "Sac à Dos Cuir Voyage Urbain",
                description = "Sac à dos en cuir véritable avec compartiment PC portable 15.6\", port USB et fermeture antivol.",
                priceFcfa = 24000,
                category = "Accessoires",
                stock = 7,
                iconName = "bag"
            )
        )
    }
}

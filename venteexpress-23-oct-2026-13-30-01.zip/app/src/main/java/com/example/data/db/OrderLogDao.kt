package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.OrderLog
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderLogDao {
    @Query("SELECT * FROM order_logs ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<OrderLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderLog): Long

    @Query("DELETE FROM order_logs")
    suspend fun clearHistory()
}

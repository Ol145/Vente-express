package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.db.OrderLogDao
import com.example.data.db.ProductDao
import com.example.data.db.StoreSettingsDao
import com.example.data.model.OrderLog
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ShopRepository(
    private val productDao: ProductDao,
    private val storeSettingsDao: StoreSettingsDao,
    private val orderLogDao: OrderLogDao
) {
    val productsFlow: Flow<List<Product>> = productDao.getAllProducts()
    val settingsFlow: Flow<StoreSettings?> = storeSettingsDao.getSettingsFlow()
    val ordersFlow: Flow<List<OrderLog>> = orderLogDao.getAllOrders()

    suspend fun ensureInitialized() {
        val count = productDao.getProductCount()
        if (count == 0) {
            productDao.insertProducts(AppDatabase.getDefaultProducts())
        }
        val settings = storeSettingsDao.getSettings()
        if (settings == null) {
            storeSettingsDao.insertOrUpdate(
                StoreSettings(
                    id = 1,
                    storeName = "VenteExpress Boutique",
                    whatsappNumber = "+221770000000",
                    adminPin = "1234",
                    currency = "FCFA"
                )
            )
        }
    }

    suspend fun getProductById(id: Int): Product? = productDao.getProductById(id)

    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)

    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)

    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)

    suspend fun deleteProductById(id: Int) = productDao.deleteProductById(id)

    suspend fun getSettings(): StoreSettings {
        return storeSettingsDao.getSettings() ?: StoreSettings(
            id = 1,
            storeName = "VenteExpress Boutique",
            whatsappNumber = "+221770000000",
            adminPin = "1234"
        )
    }

    suspend fun updateSettings(settings: StoreSettings) = storeSettingsDao.insertOrUpdate(settings)

    suspend fun logOrder(order: OrderLog) = orderLogDao.insertOrder(order)
}

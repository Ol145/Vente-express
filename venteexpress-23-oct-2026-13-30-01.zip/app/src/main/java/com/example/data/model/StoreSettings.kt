package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "store_settings")
data class StoreSettings(
    @PrimaryKey
    val id: Int = 1,
    val storeName: String = "VenteExpress Boutique",
    val whatsappNumber: String = "+221770000000",
    val adminPin: String = "1234",
    val currency: String = "FCFA",
    val sellerGreeting: String = "Bonjour, je souhaite commander cet article depuis l'application VenteExpress :"
)

package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val priceFcfa: Int,
    val category: String,
    val stock: Int = 10,
    val iconName: String = "bag",
    val imageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

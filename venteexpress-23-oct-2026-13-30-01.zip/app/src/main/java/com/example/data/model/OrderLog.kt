package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "order_logs")
data class OrderLog(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val productId: Int,
    val productTitle: String,
    val quantity: Int,
    val unitPrice: Int,
    val totalPrice: Int,
    val buyerName: String,
    val buyerCity: String,
    val timestamp: Long = System.currentTimeMillis()
)

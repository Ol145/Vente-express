package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

object WhatsAppHelper {

    /**
     * Cleans an international phone number to keep only digits (e.g. "+221 77 000 00 00" -> "221770000000").
     */
    fun cleanPhoneNumber(raw: String): String {
        return raw.replace(Regex("[^0-9]"), "")
    }

    /**
     * Generates a pre-filled WhatsApp order message.
     */
    fun buildOrderMessage(
        greeting: String,
        productTitle: String,
        productId: Int,
        quantity: Int,
        unitPrice: Int,
        totalPrice: Int,
        buyerName: String,
        buyerCity: String
    ): String {
        val formattedPrice = PriceFormatter.formatFcfa(totalPrice)
        val formattedUnit = PriceFormatter.formatFcfa(unitPrice)

        val sb = StringBuilder()
        sb.append(greeting.trim()).append("\n\n")
        sb.append("🛍️ *COMMANDE VENTEEXPRESS*\n")
        sb.append("━━━━━━━━━━━━━━━━━━━\n")
        sb.append("📦 *Article :* ").append(productTitle).append("\n")
        sb.append("🔖 *Réf. :* #").append(productId).append("\n")
        sb.append("🔢 *Quantité :* ").append(quantity).append("\n")
        if (quantity > 1) {
            sb.append("💵 *Prix unitaire :* ").append(formattedUnit).append("\n")
        }
        sb.append("💰 *TOTAL :* *").append(formattedPrice).append("*\n")
        sb.append("━━━━━━━━━━━━━━━━━━━\n")

        if (buyerName.isNotBlank()) {
            sb.append("👤 *Client :* ").append(buyerName.trim()).append("\n")
        }
        if (buyerCity.isNotBlank()) {
            sb.append("📍 *Ville / Adresse :* ").append(buyerCity.trim()).append("\n")
        }

        sb.append("\nMerci de me confirmer la disponibilité et les modalités de livraison !")
        return sb.toString()
    }

    /**
     * Opens WhatsApp directly with prefilled message.
     * Falls back to web browser if WhatsApp app is not installed.
     */
    fun sendWhatsAppOrder(
        context: Context,
        phoneNumber: String,
        message: String
    ): Boolean {
        val cleanPhone = cleanPhoneNumber(phoneNumber)
        if (cleanPhone.isEmpty()) {
            Toast.makeText(context, "Numéro WhatsApp du vendeur non configuré", Toast.LENGTH_LONG).show()
            return false
        }

        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            // First try WhatsApp direct URI schema
            val whatsappUri = Uri.parse("whatsapp://send?phone=$cleanPhone&text=$encodedMessage")
            val intent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return true
        } catch (_: Exception) {
            // Fallback to universal web link (works in browser or app)
            return try {
                val encodedMessage = URLEncoder.encode(message, "UTF-8")
                val webUri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage")
                val browserIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(browserIntent)
                true
            } catch (e2: Exception) {
                Toast.makeText(context, "Impossible d'ouvrir WhatsApp : ${e2.localizedMessage}", Toast.LENGTH_LONG).show()
                false
            }
        }
    }
}

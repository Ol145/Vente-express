package com.example.util

import java.text.NumberFormat
import java.util.Locale

object PriceFormatter {
    fun formatFcfa(amount: Int): String {
        val formatter = NumberFormat.getIntegerInstance(Locale.FRANCE)
        return "${formatter.format(amount)} FCFA"
    }

    fun formatDate(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        return sdf.format(java.util.Date(timestamp))
    }
}

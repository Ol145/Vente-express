package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.PriceFormatter
import com.example.util.WhatsAppHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VenteExpress", appName)
    }

    @Test
    fun `test price formatter fcfa`() {
        val formatted = PriceFormatter.formatFcfa(50000)
        assertTrue(formatted.contains("50") && formatted.contains("FCFA"))
    }

    @Test
    fun `test whatsapp message builder`() {
        val message = WhatsAppHelper.buildOrderMessage(
            greeting = "Bonjour",
            productTitle = "Samsung Galaxy S24",
            productId = 1,
            quantity = 2,
            unitPrice = 500000,
            totalPrice = 1000000,
            buyerName = "Fatou",
            buyerCity = "Dakar"
        )
        assertTrue(message.contains("Samsung Galaxy S24"))
        assertTrue(message.contains("Fatou"))
        assertTrue(message.contains("FCFA"))
        assertTrue(message.contains("TOTAL"))
    }

    @Test
    fun `test clean phone number`() {
        val cleaned = WhatsAppHelper.cleanPhoneNumber("+221 77 123 45 67")
        assertEquals("221771234567", cleaned)
    }
}

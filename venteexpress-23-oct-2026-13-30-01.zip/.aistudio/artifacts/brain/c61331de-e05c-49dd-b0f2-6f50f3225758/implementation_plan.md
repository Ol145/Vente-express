# VenteExpress - Boutique E-Commerce avec Commande Directe WhatsApp

Une application Android e-commerce moderne et fluide où seul l'administrateur (authentifié par un code PIN secret) peut ajouter, modifier et supprimer des produits. Les clients explorent le catalogue, choisissent leurs articles et déclenchent l'achat, qui génère instantanément un bon de commande pré-formaté et les redirige directement vers la conversation WhatsApp du vendeur.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Les décisions clés suivantes ont été validées lors de l'échange initial et constituent la base de conception :

- **Sécurité Administrateur (Validé)** : Accès protégé par un Code PIN secret configurable (par défaut initialisé à `1234`, modifiable à tout moment dans l'espace Admin avec confirmation de l'ancien code).
- **Numéro WhatsApp Vendeur (Validé)** : Un numéro WhatsApp fixe unique pour l'ensemble de la boutique, paramétrable depuis l'espace administrateur (avec indicatif international, ex: `+221...` ou `+33...`).
- **Devise du Catalogue (Validé)** : Prix en **FCFA (XOF/XAF)** avec séparateur de milliers et formatage élégant.
- **Redirection WhatsApp Fluide** : Utilisation d'un Intent Android ciblant l'application WhatsApp (`whatsapp://send` et `https://wa.me/`) contenant un message récapitulatif complet de la commande (nom du client, adresse/ville optionnelle, article, référence, quantité, prix total, date).

---

### 1. Overview & Core Concept

- **Pour l'acheteur (Client)** :
  - Découvrir les articles par catégories (High-Tech, Mode, Maison, Beauté, Accessoires).
  - Rechercher et filtrer les articles par nom, prix et disponibilité.
  - Consulter la fiche produit détaillée avec badge de stock, description, caractéristiques et prix.
  - Acheter en 1 clic : ouverture d'une feuille de commande (modal) pour renseigner son nom et numéro de livraison facultatif, puis redirection automatique immédiate vers le WhatsApp du vendeur avec le texte de la commande prêt à l'envoi.
- **Pour le vendeur (Administrateur)** :
  - Accéder à l'espace Admin via un bouton discret sécurisé par code PIN.
  - Ajouter de nouveaux produits (titre, prix en FCFA, catégorie, description, stock, image/icône visuelle thématique).
  - Mettre à jour les stocks, modifier les prix ou supprimer des articles.
  - Modifier le numéro WhatsApp de réception des commandes et le code PIN secret.
  - Consulter l'historique des commandes envoyées depuis l'application.

---

### 2. User Experience & Visual Design

#### Parcours Utilisateur Clés
1. **Écran Boutique (Accueil Client)** :
   - En-tête avec nom de la boutique, statut du vendeur (En ligne / Prêt sur WhatsApp), barre de recherche rapide et bouton d'accès Admin (icône cadenas).
   - Sélecteur horizontal de catégories avec pastilles animées.
   - Grille de cartes produits modernes avec étiquette de prix en vert émeraude, statut de stock et bouton d'action principal « Commander via WhatsApp ».
2. **Fiche Produit & Modal d'Achat** :
   - Fiche produit détaillée avec grand visuel, description claire et sélecteur de quantité.
   - Modal « Confirmer la commande » : le client saisit son prénom / numéro ou valide directement, et clique sur « Envoyer la commande ».
   - Lancement immédiat de WhatsApp avec message type :
     > *« Bonjour ! Je souhaite commander : [Nom Produit] (Réf: #102) x 1 à 15 000 FCFA. Mon nom : Amadou. Merci de confirmer la disponibilité et la livraison ! »*
3. **Espace Administrateur Sécurisé** :
   - Dialogue de saisie du PIN secret à 4 ou 6 chiffres.
   - Tableau de bord avec statistiques (total articles, articles en rupture, commandes initiées).
   - Formulaire d'ajout rapide de produit avec validation de champs.
   - Onglet Réglages pour mettre à jour le numéro WhatsApp de contact et le code PIN.

#### Identité Visuelle & Thème
- **Palette de couleurs (Modern African Commerce & WhatsApp Integration)** :
  - *Primaire* : Vert Émeraude Profond (`#0F5132` / `#128C7E` inspiré de WhatsApp et du dynamisme commercial).
  - *Accent* : Vert WhatsApp éclatant (`#25D366`) pour les boutons d'appel à l'action.
  - *Fonds & Cartes* : Fond doux (`#F8F9FA`), cartes épurées en blanc pur (`#FFFFFF`) avec ombres douces et bordures subtiles (`#E9ECEF`).
  - *Prix & Badges* : Badge doré/ambre (`#D97706`) pour le stock limité et vert pour le prix.
- **Typographie** :
  - Titres audacieux et clairs pour les noms de produits et prix.
  - Chiffres de prix formatés lisiblement (ex: `25 000 FCFA`).
- **Composants & Ergonomie** :
  - Cibles tactiles ≥ 48dp conformes Material Design 3.
  - Gestion des zones d'insets bord-à-bord (`safeDrawing`, barre de navigation).
  - Retour visuel avec ondulations Material Ripple et notifications Snackbars.

---

### 3. Key Product Decisions & Trade-Offs

- **Persistance Locale avec Room** :
  - *Choix* : Base de données SQLite Room pré-remplie avec des produits d'exemple attractifs, permettant une utilisation instantanée et 100% fonctionnelle hors-ligne, tout en conservant les ajouts et modifications de l'admin.
  - *Pourquoi* : Simplicité, performance immédiate sans latence réseau, respect des préférences utilisateur pour une application autonome.
- **Redirection WhatsApp via Intent Universel** :
  - *Choix* : Construction d'un Intent `Intent.ACTION_VIEW` avec URL formatée `https://wa.me/<phone>?text=<encoded_text>`.
  - *Pourquoi* : Fonctionne universellement, que l'acheteur ait WhatsApp, WhatsApp Business, ou doive passer par le navigateur web mobile, sans nécessiter d'API payante WhatsApp Cloud.
- **Authentification Admin par PIN Local** :
  - *Choix* : PIN stocké de façon sécurisée dans les préférences de la base de données.
  - *Pourquoi* : Expérience d'administration légère, sans barrière complexe d'authentification tierce, parfaitement adaptée au vendeur gérant sa boutique depuis son smartphone.

---

### 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────┐
│                      Composables UI                          │
│  ┌───────────────────────┐        ┌───────────────────────┐  │
│  │   CatalogScreen       │        │   AdminDashboard      │  │
│  │  - Product Grid       │        │  - Add/Edit Product   │  │
│  │  - Category Pills     │        │  - WhatsApp Settings  │  │
│  │  - Order Bottom Sheet │        │  - PIN Code Manager   │  │
│  └───────────┬───────────┘        └───────────┬───────────┘  │
└──────────────┼────────────────────────────────┼──────────────┘
               ▼                                ▼
┌──────────────────────────────────────────────────────────────┐
│                    ShopViewModel (StateFlow)                 │
│  - currentScreen: Catalog / AdminLogin / AdminPanel          │
│  - products: StateFlow<List<Product>>                        │
│  - storeSettings: StateFlow<StoreSettings>                   │
│  - triggerWhatsAppOrder(product, buyerInfo, context)         │
│  - addProduct(), deleteProduct(), updatePin(), updatePhone() │
└──────────────────────────────┬───────────────────────────────┘
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                     Repository Layer                         │
│  ┌────────────────────────────────────────────────────────┐  │
│  │ ShopRepository (AppDatabase)                           │  │
│  │  - ProductDao (getAll, insert, update, delete)         │  │
│  │  - StoreSettingsDao (getSettings, saveSettings)        │  │
│  │  - OrderHistoryDao (logOrder, getOrders)               │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

#### Modèles de données (Room Entities) :
1. **Product** :
   - `id`: Int (auto-généré)
   - `name`: String
   - `description`: String
   - `priceFcfa`: Int
   - `category`: String
   - `stock`: Int
   - `badgeIcon`: String (ex: "phone", "shirt", "shoe", "watch", "laptop", "bag", "gem")
   - `createdAt`: Long
2. **StoreSettings** :
   - `id`: Int (singleton = 1)
   - `storeName`: String
   - `sellerWhatsApp`: String (ex: "+221770000000")
   - `adminPin`: String (ex: "1234")
   - `currency`: String ("FCFA")
3. **OrderLog** :
   - `id`: Int
   - `productName`: String
   - `totalPrice`: Int
   - `buyerName`: String
   - `timestamp`: Long
